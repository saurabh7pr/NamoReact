import React from 'react'
import User from './User'

function About() {
  
  return (
    
  
      <div className='user-container'>
         <User ></User>
     
      </div>
    
 
  )
}

export default About